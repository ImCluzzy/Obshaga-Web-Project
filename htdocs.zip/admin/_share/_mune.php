<div class="buttons">
	<a class="button is-info" href="./home.php">
	    <span>Личная информация</span>
	</button>
	<a class="button is-info" href="./add_teacher.php">
	    <span class="icon">
		<i class="fas fa-user"></i></i>
	    </span>
	    <span>Добавить воспитателя</span>
	</a>
	<a class="button is-info" href="./add_dorm.php">
	    <span class="icon">
		<i class="fas fa-building"></i>
	    </span>
	    <span>Добавить общежитие</span>
	</a>
	<a class="button is-info" href="./add_student.php">
	    <span class="icon">
		<i class="fas fa-user-graduate"></i>
	    </span>
	    <span>Добавить учащегося</span>
	</a>
	<a class="button" href="../public/logout.php">
	    <span class="icon">
			<i class="fas fa-sign-out-alt"></i>
	    </span>
	    <span>Выйти</span>
	</a>
</div>