<div class="buttons">
	<a class="button is-info" href="./home.php">
	    <span class="icon">
			<i class="fas fa-user"></i>
	    </span>
	    <span>Личная информация</span>
	</a>
	<a class="button is-info" href="./leave.php">
	    <span class="icon">
			<i class="fas fa-suitcase-rolling"></i>
	    </span>
	    <span>Выбытие/прибытие</span>
	</a>
	<a class="button is-info" href="./violation.php">
	    <span class="icon">
			<i class="fas fa-clipboard-list"></i>
	    </span>
	    <span>Взыскание учащихся</span>
	</a>
	<a class="button is-info" href="./add_incentives.php">
	    <span>Добавить поощрение</span>
	</a>
	<a class="button is-info" href="./add_position.php">
	    <span>Добавить общ. работу</span>
	</a>
	<a class="button is-info" href="./exchange.php">
	    <span class="icon">
			<i class="fas fa-exchange-alt"></i>
	    </span>
	    <span>Смена общежития</span>
	</a>
	<a class="button is-info" href="./maintain_teacher.php">
	    <span class="icon">
			<i class="fas fa-wrench"></i>
	    </span>
	    <span>Заявления о проблемах</span>
	</a>
	<a class="button" href="../public/logout.php">
	    <span class="icon">
			<i class="fas fa-sign-out-alt"></i>
	    </span>
	    <span>Выйти из аккаунта</span>
	</a>
</div>
