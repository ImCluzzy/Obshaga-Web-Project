<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title>управления общежитием</title>
    <script src="../lib/jquery-3.3.1.min.js" type="text/javascript"></script>
   	<script src="../lib/all.min.js" type="text/javascript"></script>
	<script src="../lib/aos.js" type="text/javascript"></script>
	<link href="../lib/bulma.min.css" rel="stylesheet"/>
	<link href="../lib/aos.css" rel="stylesheet" />
</head>
<html>
	<body style="background-image: url(../img/bg.png);">  