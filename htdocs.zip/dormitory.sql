-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 12 2024 г., 17:41
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dormitory`
--

-- --------------------------------------------------------

--
-- Структура таблицы `t_admin`
--

CREATE TABLE `t_admin` (
  `id` int(11) UNSIGNED NOT NULL,
  `account` varchar(100) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `name` varchar(30) NOT NULL,
  `sex` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_admin`
--

INSERT INTO `t_admin` (`id`, `account`, `pwd`, `name`, `sex`) VALUES
(1, '1', '$2y$10$WQ2UmmDWuR11D8af9A74mO0bF9o10eHMnjBlRHJmadH09RnCV.gJu', 'Админ', '1'),
(2, '2', '$2y$10$ut4yM1qWC8/vGtluO8oh5er8Jmaq6Med2kMcLwh.o1cp44ieYNcd6', '2', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `t_dorm`
--

CREATE TABLE `t_dorm` (
  `id` int(11) UNSIGNED NOT NULL,
  `number` varchar(10) NOT NULL,
  `count_places` varchar(4) DEFAULT NULL,
  `svobodno_mest` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_dorm`
--

INSERT INTO `t_dorm` (`id`, `number`, `count_places`, `svobodno_mest`) VALUES
(28, '2', '70', 0),
(29, '3', '300', 0),
(30, '4', '300', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `t_dorm_maintain`
--

CREATE TABLE `t_dorm_maintain` (
  `id` int(10) UNSIGNED NOT NULL,
  `dorm_number` int(10) UNSIGNED NOT NULL,
  `room` int(10) NOT NULL,
  `request` varchar(255) DEFAULT NULL,
  `admin_response` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_dorm_maintain`
--

INSERT INTO `t_dorm_maintain` (`id`, `dorm_number`, `room`, `request`, `admin_response`, `date`, `student_id`) VALUES
(20, 3, 200, 'Не работает туалет, 3 этаж, 2 блок', 'Устраненно', '2024-06-06 21:59:00', 33),
(22, 3, 212, 'Не работает розетка, 3 этаж, 212 комната', 'Устраненно', '2024-12-12 11:09:56', 33);

-- --------------------------------------------------------

--
-- Структура таблицы `t_incentives`
--

CREATE TABLE `t_incentives` (
  `student_id` int(11) NOT NULL,
  `detail_inc` varchar(225) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `t_incentives`
--

INSERT INTO `t_incentives` (`student_id`, `detail_inc`, `date`) VALUES
(33, 'Добавка 10% к стипедии', '2024-06-01'),
(33, 'Надбавка к стипендии 15%', '2024-06-03'),
(33, 'Ну просто он долбаёб который пропускает пары и сидит за аппаратурой ', '2024-12-12'),
(41, 'Просто Молодец!', '2024-12-12');

-- --------------------------------------------------------

--
-- Структура таблицы `t_position`
--

CREATE TABLE `t_position` (
  `name` varchar(100) NOT NULL,
  `role` varchar(255) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `t_position`
--

INSERT INTO `t_position` (`name`, `role`, `student_id`) VALUES
('МООП', 'глава', 34),
('Староста кухни', 'староста', 33);

-- --------------------------------------------------------

--
-- Структура таблицы `t_student`
--

CREATE TABLE `t_student` (
  `id` int(11) UNSIGNED NOT NULL,
  `account` varchar(100) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `name` varchar(30) NOT NULL,
  `dormitory_numb` int(10) UNSIGNED DEFAULT NULL,
  `dormitory_room` int(10) DEFAULT NULL,
  `group_name` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `curator_name` varchar(255) DEFAULT NULL,
  `curator_phone` varchar(13) DEFAULT NULL,
  `parent_names` varchar(255) DEFAULT NULL,
  `parent_phone` varchar(13) DEFAULT NULL,
  `hobbies` varchar(255) DEFAULT NULL,
  `position_role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_student`
--

INSERT INTO `t_student` (`id`, `account`, `pwd`, `name`, `dormitory_numb`, `dormitory_room`, `group_name`, `address`, `curator_name`, `curator_phone`, `parent_names`, `parent_phone`, `hobbies`, `position_role`) VALUES
(33, '1', '$2y$10$t/NBkTfKVHlevn1xC.aKDOkMKNS5Os9jWgmn6ugjX6XlX.iLnew/C', 'Лешков Николай Алекснадрович', 0, NULL, '2120', 'Минская обл. Крупский район, аг.Замки, ул.Мира, д.21', 'Волотовская Татьяна Евгеньевна', '80299917555', 'Лешков Александр Владимироваич', '80299917505', 'Футбол', NULL),
(35, '1234', '$2y$10$JnwYOEdbbRMRJ.xo78hF4OSH3G064D35RhQtLl31MaKzwxKwfrP.K', 'Синькевич Олег Алекснадрович', 4, 201, '2121', 'город Минск, улица Строителей, д.21, кв.10', 'Ванькович Тамара Викторовна', '+375299917607', 'Синькевич Александр Дмитриевич', '+375299967787', 'Баскетбол', NULL),
(40, '10', '$2y$10$5HwgI7lFgPxgqTf0RjXVbuoxMq8oVYGn2s1qZcKvTUAMXWKN7wS.6', 'Аверин Алексей Незнаю', 0, NULL, '2122', 'Студенченская, 2', 'Чиков Владислав Владимирович', '+375445175653', 'Аверина Мама Незнаю', '+375445175653', 'Волейбол', NULL),
(41, '11', '$2y$10$D4T3gmzaFMnFxafV11Gzj.kH6nyq1lGV3dOoB4t1/820UdtIEkgvm', 'Дятлик Арсений Юрьевич', 3, NULL, '2122', 'г. Молодечно, ул. Полоцкая, 31-1', 'Чиков Владислав Владимирович', '883957988', 'Дятлик Марина Антоновна', '883957988', 'Волейбол, Программирование', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `t_student_dorm`
--

CREATE TABLE `t_student_dorm` (
  `id` int(11) UNSIGNED NOT NULL,
  `student_id` int(11) UNSIGNED NOT NULL,
  `dorm_id` int(11) UNSIGNED NOT NULL,
  `supervisor` char(1) NOT NULL DEFAULT 'n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблицы `t_student_dorm_exchange`
--

CREATE TABLE `t_student_dorm_exchange` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `to_dorm_number` int(10) UNSIGNED NOT NULL,
  `to_dorm_room` int(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `request` varchar(255) NOT NULL,
  `teacher_response` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_student_dorm_exchange`
--

INSERT INTO `t_student_dorm_exchange` (`id`, `student_id`, `to_dorm_number`, `to_dorm_room`, `date`, `request`, `teacher_response`) VALUES
(40, 33, 3, 212, '2024-06-06 22:12:32', 'Хочу переехать в связи с плохими соседями', 'Переселен'),
(41, 33, 3, 201, '2024-12-10 18:47:39', 'Хочу переселиться по причине того что не устраивают соседи', 'Утверждено'),
(42, 33, 4, 209, '2024-06-06 00:00:00', 'Хочу переселиться по причине плохих соседей', 'На рассмотрении'),
(43, 33, 4, 213, '2024-06-06 00:00:00', 'Хочу переселиться по причине плохих соседей', 'На рассмотрении');

-- --------------------------------------------------------

--
-- Структура таблицы `t_student_leave`
--

CREATE TABLE `t_student_leave` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `request` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблицы `t_student_violation`
--

CREATE TABLE `t_student_violation` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `detail` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `teacher_response` varchar(255) DEFAULT NULL,
  `punishment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_student_violation`
--

INSERT INTO `t_student_violation` (`id`, `student_id`, `detail`, `date`, `teacher_response`, `punishment`) VALUES
(32, 33, '10ч отработки', '2024-06-06 00:00:00', NULL, 'Курил на территории общежития '),
(33, 33, 'Отработка 5 часов', '2024-06-06 00:00:00', NULL, 'Распитие спиртных напитков в общежитии');

-- --------------------------------------------------------

--
-- Структура таблицы `t_teacher`
--

CREATE TABLE `t_teacher` (
  `id` int(11) UNSIGNED NOT NULL,
  `account` varchar(100) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dorm_numb` varchar(10) NOT NULL,
  `phone_number` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `t_teacher`
--

INSERT INTO `t_teacher` (`id`, `account`, `pwd`, `name`, `dorm_numb`, `phone_number`) VALUES
(35, '1', '$2y$10$xJN0TiTkOev3FzKvAfUL8elXW3Dt1nAOupO7RsUrAbsdyXuatM10G', 'Бегун Лолита Михайловна', '2', '+375291111111'),
(37, '3', '$2y$10$LEWVyQExD8VALjHOjGy.5eVcHZcDdtwvFQoe8jYAG.4RXTV3zrg9e', 'Садовский Максим Незнаю', '4', '+375291111111'),
(38, '10', '$2y$10$PFJlk1syop8g74ODKoogYuC4mcHOpdBPUcHYlafRNxLquCbHKqqcW', 'Козлова Марина Геннадьевна', '3', '+375291111111');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `t_admin`
--
ALTER TABLE `t_admin`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `account` (`account`) USING BTREE;

--
-- Индексы таблицы `t_dorm`
--
ALTER TABLE `t_dorm`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `number` (`number`);

--
-- Индексы таблицы `t_dorm_maintain`
--
ALTER TABLE `t_dorm_maintain`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `dorm_id` (`dorm_number`) USING BTREE;

--
-- Индексы таблицы `t_student`
--
ALTER TABLE `t_student`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `account` (`account`) USING BTREE,
  ADD KEY `class_id` (`dormitory_numb`) USING BTREE;

--
-- Индексы таблицы `t_student_dorm`
--
ALTER TABLE `t_student_dorm`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `student_id` (`student_id`) USING BTREE,
  ADD KEY `dorm_id` (`dorm_id`) USING BTREE;

--
-- Индексы таблицы `t_student_dorm_exchange`
--
ALTER TABLE `t_student_dorm_exchange`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `student_id` (`student_id`) USING BTREE,
  ADD KEY `to_dorm_id` (`to_dorm_number`) USING BTREE;

--
-- Индексы таблицы `t_student_leave`
--
ALTER TABLE `t_student_leave`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `student_id` (`student_id`) USING BTREE;

--
-- Индексы таблицы `t_student_violation`
--
ALTER TABLE `t_student_violation`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `student_id` (`student_id`) USING BTREE;

--
-- Индексы таблицы `t_teacher`
--
ALTER TABLE `t_teacher`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `account` (`account`) USING BTREE,
  ADD KEY `name` (`name`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `t_admin`
--
ALTER TABLE `t_admin`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `t_dorm`
--
ALTER TABLE `t_dorm`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `t_dorm_maintain`
--
ALTER TABLE `t_dorm_maintain`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `t_student`
--
ALTER TABLE `t_student`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT для таблицы `t_student_dorm`
--
ALTER TABLE `t_student_dorm`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT для таблицы `t_student_dorm_exchange`
--
ALTER TABLE `t_student_dorm_exchange`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT для таблицы `t_student_leave`
--
ALTER TABLE `t_student_leave`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `t_student_violation`
--
ALTER TABLE `t_student_violation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT для таблицы `t_teacher`
--
ALTER TABLE `t_teacher`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `t_student_dorm`
--
ALTER TABLE `t_student_dorm`
  ADD CONSTRAINT `t_student_dorm_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `t_student` (`id`),
  ADD CONSTRAINT `t_student_dorm_ibfk_2` FOREIGN KEY (`dorm_id`) REFERENCES `t_dorm` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
