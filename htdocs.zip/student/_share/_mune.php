<<div class="buttons">
	<a class="button is-info" href="./home.php">
	    <span class="icon">
			<i class="fas fa-user"></i>
	    </span>
	    <span>Личная информация</span>
	</a>
	<a class="button is-info" href="./maintain.php">
	    <span class="icon">
			<i class="fas fa-wrench"></i>
	    </span>
	    <span>Сообщить о проблеме</span>
	</a>
	<a class="button is-info" href="./leave.php">
	    <span class="icon">
			<i class="fas fa-suitcase-rolling"></i>
	    </span>
	    <span>Выбытие и прибытие</span>
	</a>
	<a class="button is-info" href="./exchange.php">
	    <span class="icon">
			<i class="fas fa-exchange-alt"></i>
	    </span>
	    <span>Заявка на переселение</span>
	</a>
	<a class="button is-info" href="./violation.php">
	    <span class="icon">
			<i class="fas fa-clipboard-list"></i>
	    </span>
	    <span>Записи взысканий</span>
	</a>
	<a class="button" href="../public/logout.php">
	    <span class="icon">
			<i class="fas fa-sign-out-alt"></i>
	    </span>
	    <span>Выйти из аккаунта</span>
	</a>
</div>
